import os
import os.path
import sys

from qgis.core import *
from qgis.gui import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *

from ui_mainWindow import Ui_MainWindow

import resources
from constants import *
from mapTools import *

class ForestTrailsWindow(QMainWindow, Ui_MainWindow):
    def __init__(self):
        QMainWindow.__init__(self)

        self.setupUi(self)

        self.connect(self.actionZoomIn, SIGNAL("triggered()"), self.zoomIn)
        self.connect(self.actionZoomOut, SIGNAL("triggered()"), self.zoomOut)
        self.connect(self.actionQuit, SIGNAL("triggered()"), self.quit)
        self.connect(self.actionPan, SIGNAL("triggered()"), self.setPanMode)
        self.connect(self.actionEdit, SIGNAL("triggered()"), self.setEditMode)
        self.connect(self.actionAddTrack, SIGNAL("triggered()"), self.addTrack)
        self.connect(self.actionEditTrack, SIGNAL("triggered()"),
                     self.editTrack)
        self.connect(self.actionDeleteTrack, SIGNAL("triggered()"),
                     self.deleteTrack)
        self.connect(self.actionGetInfo, SIGNAL("triggered()"),
                     self.getInfo)
        self.connect(self.actionSetStartPoint, SIGNAL("triggered()"),
                     self.setStartPoint)
        self.connect(self.actionSetEndPoint, SIGNAL("triggered()"),
                     self.setEndPoint)
        self.connect(self.actionFindShortestPath, SIGNAL("triggered()"),
                     self.findShortestPath)

        self.mapCanvas = QgsMapCanvas()
        self.mapCanvas.useImageToRender(False)
        self.mapCanvas.setCanvasColor(Qt.white)
        self.mapCanvas.show()

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.mapCanvas)
        self.centralWidget.setLayout(layout)


    def zoomIn(self):
        self.mapCanvas.zoomIn()


    def zoomOut(self):
        self.mapCanvas.zoomOut()


    def quit(self):
        pass


    def setPanMode(self):
        pass


    def setEditMode(self):
        pass


    def addTrack(self):
        pass


    def editTrack(self):
        pass


    def deleteTrack(self):
        pass


    def getInfo(self):
        pass


    def setStartPoint(self):
        pass


    def setEndPoint(self):
        pass


    def findShortestPath(self):
        pass




def main():
    app = QApplication(sys.argv)

    QgsApplication.setPrefixPath(os.environ['QGIS_PREFIX'], True)
    QgsApplication.initQgis()

    window = ForestTrailsWindow()
    window.show()
    window.raise_()

    app.exec_()
    app.deleteLater()
    window.close()
    QgsApplication.exitQgis()

if __name__ == "__main__":
    main()

