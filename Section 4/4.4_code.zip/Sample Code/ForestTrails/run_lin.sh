#!/bin/sh
export PYTHONPATH="/path/to/qgis/build/output/python"
export LD_LIBRARY_PATH="/path/to/qgis/build/output/lib"
export QGIS_PREFIX="/path/to/qgis/build/output/"
python forestTrails.py

