import os
import os.path
import sys

from qgis.core import *
from qgis.gui import *
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class ForestTrailsWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)


def main():
    app = QApplication(sys.argv)

    QgsApplication.setPrefixPath(os.environ['QGIS_PREFIX'], True)
    QgsApplication.initQgis()

    window = ForestTrailsWindow()
    window.show()
    window.raise_()

    app.exec_()
    app.deleteLater()
    window.close()
    QgsApplication.exitQgis()

if __name__ == "__main__":
    main()

